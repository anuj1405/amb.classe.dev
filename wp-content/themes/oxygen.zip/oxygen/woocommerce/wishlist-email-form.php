<?php
/**
 *	Oxygen WordPress Theme
 *	
 *	Laborator.co
 *	www.laborator.co 
 */

woocommerce_wishlist_register_email_form($wishlist); ?>