<?php
/**
 * Content wrappers
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */


echo '</div>';

/*
$template = get_option( 'template' );

switch( $template ) 
{
	default :
		echo '</div>';
		break;
}
*/