<?php
/**
 * Result Count
 *
 * Shows text: Showing x - x of x results
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $woocommerce, $wp_query;

if ( ! woocommerce_products_will_display() )
	return;
?>
<span class="results">
	<?php
	$paged    = max( 1, $wp_query->get( 'paged' ) );
	$per_page = $wp_query->get( 'posts_per_page' );
	$total    = $wp_query->found_posts;
	$first    = ( $per_page * $paged ) - $per_page + 1;
	$last     = min( $total, $wp_query->get( 'posts_per_page' ) * $paged );

	if ( 1 == $total ) {
		_e( ' RESULTS FOUND', 'oxygen' );
	} elseif ( $total <= $per_page || -1 == $per_page ) {
		printf( __( ' %d RESULTS FOUND', 'oxygen' ), $total );
	} else {
		printf( _x( '%1$d&ndash;%2$d of %3$d RESULTS FOUND', '%1$d = first, %2$d = last, %3$d = total', 'oxygen' ), $first, $last, $total );
	}
	?>
</span>