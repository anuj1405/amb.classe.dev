<?php
/**
 *	Oxygen WordPress Theme
 *	
 *	Laborator.co
 *	www.laborator.co 
 */

$widgets_columns = get_data('footer_widgets_columns');

?>
<footer class="footer_widgets">
	<div class="row">
	
	<?php dynamic_sidebar('footer_sidebar'); ?>
	
	<?php /*
	    <div class="col-lg-4">
	        <div class="footer-block">
	            <h3>About Oxygen</h3>
	            <p>
	                Improve ashamed married expense bed her comfort pursuit mrs. Four time took ye your as fail lady. Up greatest am exertion or marianne. Shy occasional terminated insensible and inhabiting gay. So know do fond to half on. 
	            </p>
	 
	            <ul class="social-networks">
	                <li>
	                    <a class="btn btn-social-icon btn-sm btn-facebook"><i class="fa fa-facebook"></i></a>
	                </li>
	                <li>
	                    <a class="btn btn-social-icon btn-sm btn-twitter"><i class="fa fa-twitter"></i></a>
	                </li>
	                <li>
	                    <a class="btn btn-social-icon btn-sm btn-google-plus"><i class="fa fa-google-plus"></i></a>
	                </li>
	                <li>
	                    <a class="btn btn-social-icon btn-sm btn-instagram"><i class="fa fa-instagram"></i></a>
	                </li>
	                <li>
	                    <a class="btn btn-social-icon btn-sm btn-flickr"><i class="fa fa-flickr"></i></a>
	                </li>
	           </ul>
	       </div>
	    </div>
	
	    <div class="col-lg-4 ">
	        <div class="footer-block">
	            <h3>Tags</h3>
	            <ul class="tags">
	                <li><a href="#">white</a></li>
	                <li><a href="#">elegant</a></li>
	                <li><a href="#">blue</a></li>
	                <li><a href="#">women</a></li>
	                <li><a href="#">collections</a></li>
	                <li><a href="#">new</a></li>
	                <li><a href="#">sales</a></li>
	                <li><a href="#">discount</a></li>
	                <li><a href="#">voucher</a></li>
	                <li><a href="#">shorts</a></li>
	                <li><a href="#">summer</a></li>
	                <li><a href="#">shoes</a></li>
	                <li><a href="#">kids</a></li>
	                <li><a href="#">teen</a></li>
	           </ul>
	        </div>
	    </div>
	
	    <div class="col-lg-4">
	        <div class="footer-block">
	            <h3>Newsletter</h3>
	            <p>
	                Win a coupon of 20% by subscribing to our newsletter, it's easy just enter your e-mail below:
	            </p>
	            <div class="row">
	                <form>
	                    <div class="col-lg-8 col-xs-8 no-padding">
	                        <input type="text" class="subscribe-field" id="email" placeholder="E-mail...">
	                    </div>
	                    
	                    <div class="col-lg-4 col-xs-4  no-padding">
	                        <button type="button" class="btn btn-black">Subscribe</button>
	                    </div>
	                </form>
	            </div>
	        </div> 
	    </div>*/ ?>
	</div>
</footer>
<?php

