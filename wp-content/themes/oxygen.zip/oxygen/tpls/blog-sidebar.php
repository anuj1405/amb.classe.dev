<?php
/**
 *	Oxygen WordPress Theme
 *	
 *	Laborator.co
 *	www.laborator.co 
 */

?>
<!-- blog sidebar-->
<div class="shop_sidebar blog">

	<?php dynamic_sidebar('blog_sidebar'); ?>
	
</div>
