<?php

ITSEC_Modules::register_module( 'database-prefix', dirname( __FILE__ ), 'always-active' );
