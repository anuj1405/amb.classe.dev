<?php

ITSEC_Modules::register_module( 'hide-backend', dirname( __FILE__ ), 'always-active' );
